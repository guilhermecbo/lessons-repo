/*
 
 10 col 5 linhas
 
 */
public class Exercicio01 {

	public static void main(String[] args) {
		int col = 10;
		int lin = 5;
		
		for (int l=0; l<lin; l++){			
			for (int c=0; c<col; c++){
				System.out.print("*");
			}
			System.out.print("\n");
		}//--------------------------------------------

	}//------------------------------------------------

}//----------------------------------------------------
