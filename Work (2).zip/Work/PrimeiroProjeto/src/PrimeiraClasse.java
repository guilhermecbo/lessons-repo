
public class PrimeiraClasse {

	public static void main(String[] args) {
		
		// Mostrar a mensagem laborat�rio
		// System.out.println("Laborat�rio");
		
		int numero;
		
		numero = 20;
		
		System.out.print("O conte�do da vari�vel numero � " +numero);
	}

}